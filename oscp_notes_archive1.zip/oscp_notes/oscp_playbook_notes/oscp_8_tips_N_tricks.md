# Tips & Tricks 🤸‍

### Table of Conents
1. Getting Around IP Bans

--------------------------------------------------------
--------------------------------------------------------

## 1) Getting Around IP Bans

1. Try to use **ssh** to do a **local port forward**
  + Look at the _Port Forwarding section_
   - Look at the _Local Port Forwarding_ subsection
    * In `oscp_playbook_notes/oscp_9_pivoting.md`

   
--------------------------------------------------------
--------------------------------------------------------

